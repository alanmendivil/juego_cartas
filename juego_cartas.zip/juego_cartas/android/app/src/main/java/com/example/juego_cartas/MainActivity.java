package com.example.juego_cartas;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
