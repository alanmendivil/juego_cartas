import 'package:flutter/material.dart';

void main() {
  runApp(const MemoryGame());
}

class MemoryGame extends StatelessWidget {
  const MemoryGame({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JUEGO DE MEMORIA',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const MemoryGameHome(),
    );
  }
}

class MemoryGameHome extends StatefulWidget {
  const MemoryGameHome({super.key});

  @override
  MemoryGameHomeState createState() => MemoryGameHomeState();
}

class MemoryGameHomeState extends State<MemoryGameHome> {
  List<String> cards = [];
  List<bool> flipped = [];
  int? selectedIndex;
  int gridSize = 4; // Tamaño  inicial (4x4)
  double iconSize = 32; // Tamaño de los íconos

  @override
  void initState() {
    super.initState();
    _setLevel('fácil'); // Establecer el nivel inicial en 'fácil'
  }

  void _flipCard(int index) {
    setState(() {
      if (selectedIndex == null) {
        // Primer carta seleccionada
        selectedIndex = index;
        flipped[index] = true;
      } else if (selectedIndex != index) {
        // Segunda carta seleccionada
        flipped[index] = true;


        Future.delayed(const Duration(seconds: 1), () {
          setState(() {
            if (cards[selectedIndex!] != cards[index]) {
              flipped[selectedIndex!] = false;
              flipped[index] = false;
            }
            selectedIndex = null; // Resetea la selección
          });
        });
      }
    });
  }


  void _resetGame() {
    setState(() {
      cards.shuffle();
      flipped = List.filled(cards.length, false); // Reinicia todas las cartas volteadas
      selectedIndex = null;
    });
  }


  void _setLevel(String level) {
    setState(() {
      if (level == 'fácil') {
        gridSize = 4; // 4x4
        iconSize = 32;
        cards = ["🐶", "🐱", "🐭", "🐹", "🐶", "🐱", "🐭", "🐹"];
      } else if (level == 'medio') {
        gridSize = 6; // 6x6
        iconSize = 28;
        cards = [
          "🐶", "🐱", "🐭", "🐹", "🐰", "🐼",
          "🐶", "🐱", "🐭", "🐹", "🐰", "🐼"
        ];
      } else if (level == 'difícil') {
        gridSize = 8; // 8x8
        iconSize = 24;
        cards = [
          "🐶", "🐱", "🐭", "🐹", "🐰", "🐼", "🦊", "🐸",
          "🐶", "🐱", "🐭", "🐹", "🐰", "🐼", "🦊", "🐸"
        ];
      }
      cards.shuffle(); // Baraja las cartas
      flipped = List.filled(cards.length, false);
      selectedIndex = null; // Reinicia la selección
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Juego de Memoria'),
        actions: [
          TextButton(
            onPressed: () {
              // Abre un menú para seleccionar el nivel
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('Selecciona un nivel'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: () {
                            _setLevel('fácil');
                            Navigator.of(context).pop();
                          },
                          child: const Text('Fácil (4x4)'),
                        ),
                        TextButton(
                          onPressed: () {
                            _setLevel('medio');
                            Navigator.of(context).pop();
                          },
                          child: const Text('Medio (6x6)'),
                        ),
                        TextButton(
                          onPressed: () {
                            _setLevel('difícil');
                            Navigator.of(context).pop();
                          },
                          child: const Text('Difícil (8x8)'),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
            child: const Text(
              'Niveles',
              style: TextStyle(color: Colors.lightBlue),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: gridSize,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
              ),
              itemCount: cards.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    if (!flipped[index] &&
                        (selectedIndex == null || selectedIndex != index)) {
                      _flipCard(index);
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.blueAccent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        flipped[index] ? cards[index] : "❓",
                        style: TextStyle(fontSize: iconSize, color: Colors.white),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextButton(
              onPressed: _resetGame,
              child: const Text(
                'Reiniciar Juego',
                style: TextStyle(fontSize: 20, color: Colors.blue),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
