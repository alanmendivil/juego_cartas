import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:juego_cartas/main.dart'; // Asegúrate de usar el nombre correcto del archivo principal.

void main() {
  testWidgets('Verificar que las cartas se muestren', (WidgetTester tester) async {
    // Construir el juego de memoria y desencadenar un frame.
    await tester.pumpWidget(const MemoryGame());

    // Verificar que las cartas ocultas (❓) se muestren inicialmente.
    expect(find.text('❓'), findsWidgets);

    // Simular un tap en la primera carta.
    await tester.tap(find.byType(GestureDetector).first);
    await tester.pump();

    // Verificar que la carta se voltea (es decir, ya no debe mostrar '❓').
    expect(find.text('❓'), findsNWidgets(7)); // Debería haber 7 cartas restantes con ❓.
  });
}
